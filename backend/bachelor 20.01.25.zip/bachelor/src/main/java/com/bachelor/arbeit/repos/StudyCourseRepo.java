package com.bachelor.arbeit.repos;

import com.bachelor.arbeit.entities.StudyCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface StudyCourseRepo extends JpaRepository<StudyCourse, Long> {
    @Query(value = "SELECT setval('study_course_id_seq', (SELECT MAX(id) FROM study_course));", nativeQuery = true)
    void syncSequence();
}
