package com.bachelor.arbeit.dtos;

import com.bachelor.arbeit.entities.Semester;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SemesterDTO {
    private Long id;
    private Integer semesterNumber;
    private Integer numberOfStudents;

    public static SemesterDTO mapToDTO(Semester semester){
        return SemesterDTO.builder()
                .id(semester.getId())
                .numberOfStudents(semester.getNumberOfStudents())
                .build();
    }
}
