package com.bachelor.arbeit.services;

import com.bachelor.arbeit.dtos.TimePeriodDTO;
import com.bachelor.arbeit.entities.TimePeriod;
import com.bachelor.arbeit.repos.TimePeriodRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class TimePeriodService {
    private final TimePeriodRepo repo;

    @Autowired
    public TimePeriodService(TimePeriodRepo repo) {
        this.repo = repo;
    }

    public List<TimePeriodDTO> getAllTimePeriods() {
        return repo.findAll()
                .stream()
                .map(TimePeriodDTO::mapToDTO)
                .toList();
    }

    public TimePeriodDTO createTimePeriod(TimePeriod timePeriod) {
        return TimePeriodDTO.mapToDTO(repo.save(timePeriod));
    }

    public TimePeriodDTO updateTimePeriod(Long id, TimePeriod timePeriod){
        TimePeriod existingTimePeriod = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("ID not found with number: " + id));

        existingTimePeriod.setSemesters(timePeriod.getSemesters());
        return TimePeriodDTO.mapToDTO(repo.save(existingTimePeriod));
    }

    public void deleteTimePeriod(Long id){
        repo.deleteById(id);
    }
}
