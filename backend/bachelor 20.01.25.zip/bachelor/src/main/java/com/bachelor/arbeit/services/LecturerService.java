package com.bachelor.arbeit.services;

import com.bachelor.arbeit.dtos.LecturerDTO;
import com.bachelor.arbeit.entities.Lecturer;
import com.bachelor.arbeit.entities.LecturerType;
import com.bachelor.arbeit.repos.LecturerRepo;
import com.bachelor.arbeit.repos.LecturerTypeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class LecturerService {
    private final LecturerRepo repo;
    private final LecturerTypeRepo lecturerTypeRepo;
    @Autowired
    public LecturerService(LecturerRepo repo, LecturerTypeRepo lecturerTypeRepo) {
        this.repo = repo;
        this.lecturerTypeRepo = lecturerTypeRepo;
    }

    public void syncSequence(){
        repo.syncSequence();
    }

    @Transactional
    public List<LecturerDTO> getLecturers() {
        return repo.findAll()
                .stream()
                .map(LecturerDTO::mapToDTO)
                .toList();
    }

    @Transactional
    public LecturerDTO createLecturer(LecturerDTO lecturerDTO) {
        LecturerType lecturerType = getLecturerTypeIfExists(lecturerDTO.getLecturerTypeId());

        Lecturer newLecturer = Lecturer.builder()
                .name(lecturerDTO.getName())
                .lecturerType(lecturerType)
                .build();

        repo.save(newLecturer);

        return LecturerDTO.mapToDTO(newLecturer);
    }

    @Transactional
    public LecturerDTO updateLecturer(Long id, LecturerDTO lecturerDTO) {
        Lecturer existingLecturer = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Lecturer not found with ID: " + id));

        if(lecturerDTO.getName() != null) {
            existingLecturer.setName(lecturerDTO.getName());
        }
        if(lecturerDTO.getLecturerTypeId() != null){
            LecturerType lecturerType = getLecturerTypeIfExists(lecturerDTO.getLecturerTypeId());
            existingLecturer.setLecturerType(lecturerType);
        }

        repo.save(existingLecturer);

        return LecturerDTO.mapToDTO(existingLecturer);
    }

    @Transactional
    public LecturerDTO updateLecturerTypeForLecturer(Long id, Long lecturerTypeId) {
        Lecturer lecturer = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Lecturer not found with ID: " + id));
        LecturerType lecturerType = lecturerTypeRepo.findById(lecturerTypeId)
                .orElseThrow(() -> new NoSuchElementException("Lecturer Type not found with ID: " + lecturerTypeId));

        lecturer.setLecturerType(lecturerType);

        Lecturer updatedLecturer = repo.save(lecturer);

        return LecturerDTO.mapToDTO(updatedLecturer);
    }

    @Transactional
    public boolean deleteLecturer(Long id) {
        if(repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

    private LecturerType getLecturerTypeIfExists(Long lecturerTypeId){
        if(lecturerTypeId == null){
            return null;
        }
        return lecturerTypeRepo.findById(lecturerTypeId)
                .orElseThrow(() -> new NoSuchElementException("Lecturer Type not found with ID: " + lecturerTypeId));
    }

    public Lecturer findById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("ID not found with number: " + id));
    }
}
