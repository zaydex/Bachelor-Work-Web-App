package com.bachelor.arbeit.dtos;

import com.bachelor.arbeit.entities.CourseSemester;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CourseSemesterDTO {
    private Long id;
    private Long courseId;
    private Long semesterId;
    private Boolean toPlan = false;

    public static CourseSemesterDTO mapToDTO (CourseSemester courseSemester){
        return CourseSemesterDTO.builder()
                .id(courseSemester.getId())
                .courseId(courseSemester.getCourse().getId())
                .semesterId(courseSemester.getSemester().getId())
                .toPlan(courseSemester.getToPlan())
                .build();
    }
}
