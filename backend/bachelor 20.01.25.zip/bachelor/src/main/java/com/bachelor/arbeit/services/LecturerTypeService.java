package com.bachelor.arbeit.services;

import com.bachelor.arbeit.dtos.LecturerDTO;
import com.bachelor.arbeit.dtos.LecturerTypeDTO;
import com.bachelor.arbeit.entities.LecturerType;
import com.bachelor.arbeit.repos.LecturerRepo;
import com.bachelor.arbeit.repos.LecturerTypeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LecturerTypeService {
    private final LecturerTypeRepo repo;
    private final LecturerRepo lecturerRepo;

    @Autowired
    public LecturerTypeService(LecturerTypeRepo repo, LecturerRepo lecturerRepo) {
        this.repo = repo;
        this.lecturerRepo = lecturerRepo;
    }

    public void syncSequence() {
        repo.syncSequence();
    }

    @Transactional
    public List<LecturerTypeDTO> getLecturerTypes() {
        return repo.findAll()
                .stream()
                .map(LecturerTypeDTO::mapToDTO)
                .toList();
    }

    @Transactional
    public Set<LecturerDTO> getLecturersByLecturerType(Long id) {
        return lecturerRepo.findAllByLecturerType_Id(id)
                .stream()
                .map(LecturerDTO::mapToDTO)
                .collect(Collectors.toSet());
    }

    @Transactional
    public LecturerTypeDTO createLecturerType(LecturerTypeDTO lecturerTypeDTO) {
        LecturerType newType = LecturerTypeDTO.mapToEntity(lecturerTypeDTO);
        repo.save(newType);

        return LecturerTypeDTO.mapToDTO(newType);
    }

    @Transactional
    public LecturerTypeDTO updateLecturerType(Long id, LecturerTypeDTO lecturerTypeDTO) {
        LecturerType updateExistingLecturerType = repo.findById(id).orElseThrow();

        if(lecturerTypeDTO.getTypeName() != null) {
            updateExistingLecturerType.setTypeName(lecturerTypeDTO.getTypeName());
        }
        if(lecturerTypeDTO.getRequiredHours() != null) {
            updateExistingLecturerType.setRequiredHours(lecturerTypeDTO.getRequiredHours());
        }
        if(lecturerTypeDTO.getLectureship() != null) {
            updateExistingLecturerType.setLectureship(lecturerTypeDTO.getLectureship());
        }

        repo.save(updateExistingLecturerType);

        return LecturerTypeDTO.mapToDTO(updateExistingLecturerType);
    }

    @Transactional
    public boolean deleteLecturerType(Long id) {
        if(repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }
}
