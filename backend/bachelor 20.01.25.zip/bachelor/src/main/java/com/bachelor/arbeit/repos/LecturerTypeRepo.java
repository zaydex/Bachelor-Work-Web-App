package com.bachelor.arbeit.repos;

import com.bachelor.arbeit.entities.LecturerType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface LecturerTypeRepo extends JpaRepository<LecturerType, Long> {
    @Query(value = "SELECT setval('lecturer_type_id_seq', (SELECT MAX(id) FROM lecturer_type));", nativeQuery = true)
    void syncSequence();
}
