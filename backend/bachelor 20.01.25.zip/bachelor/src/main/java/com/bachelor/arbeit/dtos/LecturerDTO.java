package com.bachelor.arbeit.dtos;

import com.bachelor.arbeit.entities.Lecturer;
import lombok.Builder;
import lombok.Data;


@Builder
@Data
public class LecturerDTO {
    private Long id;
    private String name;
    private Long lecturerTypeId;

    public static LecturerDTO mapToDTO(Lecturer lecturer){
        return LecturerDTO.builder()
                .id(lecturer.getId())
                .name(lecturer.getName())
                .lecturerTypeId(lecturer.getLecturerType() != null ? lecturer.getLecturerType().getId() : null)
                .build();
    }
}
