package com.bachelor.arbeit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BachelorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BachelorApplication.class, args);
	}

}
