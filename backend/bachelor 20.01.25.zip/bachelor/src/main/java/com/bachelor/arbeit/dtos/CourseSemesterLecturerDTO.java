package com.bachelor.arbeit.dtos;

import com.bachelor.arbeit.entities.CourseSemesterLecturer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CourseSemesterLecturerDTO {
    private Long id;
    private Long courseSemesterId;
    private Long lecturerId;
    private String comment;
    private Integer numberOfStudents;
    private Integer numberOfGroups;

    public static CourseSemesterLecturerDTO mapToDTO(CourseSemesterLecturer courseSemesterLecturer){
        return CourseSemesterLecturerDTO.builder()
                .id(courseSemesterLecturer.getId())
                .courseSemesterId(courseSemesterLecturer.getCourseSemester().getId())
                .lecturerId(courseSemesterLecturer.getLecturer().getId())
                .comment(courseSemesterLecturer.getComment())
                .numberOfStudents(courseSemesterLecturer.getNumberOfStudents())
                .numberOfGroups(courseSemesterLecturer.getNumberOfGroups())
                .build();
    }
}
