package com.bachelor.arbeit.dtos;

import com.bachelor.arbeit.entities.Semester;
import com.bachelor.arbeit.entities.StudyCourse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.*;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudyCourseDTO {
    private Long id;
    private String name;
    private Integer numberOfSemesters;

    public static StudyCourseDTO mapToDTO(StudyCourse studyCourse){
        return StudyCourseDTO.builder()
                .id(studyCourse.getId())
                .name(studyCourse.getName())
                .numberOfSemesters(studyCourse.getSemesters().size())
                .build();
    }
    public static StudyCourse mapToEntity(StudyCourseDTO studyCourseDTO){
        StudyCourse studyCourse = StudyCourse.builder()
                .name(studyCourseDTO.getName())
                .semesters(new ArrayList<>()) // Защита от null
                .build();

        int totalSemesters = studyCourseDTO.getNumberOfSemesters() != null ? studyCourseDTO.getNumberOfSemesters() : 0;

        for (int i = 1; i <= totalSemesters; i++) { // i начинается с 1
            Semester semester = new Semester();
            semester.setStudyCourse(studyCourse);
            semester.setSemesterNumber(i); // Заполняем номер семестра
            studyCourse.getSemesters().add(semester);
        }
        return studyCourse;
    }
}
