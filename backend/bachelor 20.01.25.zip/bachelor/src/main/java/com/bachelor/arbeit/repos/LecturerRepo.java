package com.bachelor.arbeit.repos;

import com.bachelor.arbeit.entities.Lecturer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface LecturerRepo extends JpaRepository<Lecturer, Long> {
    Set<Lecturer> findAllByLecturerType_Id(Long lecturerTypeId);

    @Query(value = "SELECT setval('lecturer_id_seq', (SELECT MAX(id) FROM lecturer));", nativeQuery = true)
    void syncSequence();
}
