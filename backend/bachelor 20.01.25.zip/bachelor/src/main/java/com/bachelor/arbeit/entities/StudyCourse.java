package com.bachelor.arbeit.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.*;

@Entity
@Data
@Table
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudyCourse {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "study_course_seq")
    @SequenceGenerator(
            name = "study_course_seq",
            sequenceName = "study_course_id_seq",  // Имя последовательности в базе данных
            allocationSize = 1  // Шаг последовательности, 1 для строгой последовательности
    )
    private Long id;
    @Column(unique = true)
    private String name;

    //Study Course -> Semesters
    @OneToMany(mappedBy = "studyCourse", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id ASC")
    private List<Semester> semesters = new ArrayList<>();
}
