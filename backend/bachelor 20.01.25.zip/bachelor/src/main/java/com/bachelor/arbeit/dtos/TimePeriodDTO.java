package com.bachelor.arbeit.dtos;

import com.bachelor.arbeit.entities.Semester;
import com.bachelor.arbeit.entities.TimePeriod;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TimePeriodDTO {
    private Long id;
    private List<Semester> semesters;

    public static TimePeriodDTO mapToDTO(TimePeriod timePeriod){
        return TimePeriodDTO.builder()
                .id(timePeriod.getId())
                .semesters(timePeriod.getSemesters())
                .build();
    }

    public static TimePeriod mapToEntity(TimePeriodDTO timePeriodDTO){
        return TimePeriod.builder()
                .id(timePeriodDTO.getId())
                .semesters(timePeriodDTO.getSemesters())
                .build();
    }
}
